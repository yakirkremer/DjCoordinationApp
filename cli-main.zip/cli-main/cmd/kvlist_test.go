package cmd

import (
	"encoding/json"
	"testing"

	renderapi "github.com/render-oss/cli/internal/fakes/renderapi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// executeKVList runs `render kv list <args>` against the fake server.
// Seeds and selects an active workspace before running the command.
func executeKVList(t *testing.T, server *renderapi.Server, extraArgs ...string) (CommandResult, error) {
	t.Helper()

	args := append([]string{"list"}, extraArgs...)
	return executeKVCommand(t, server, args...)
}

func TestKVList_NoInstances(t *testing.T) {
	server := renderapi.NewServer(t)

	result, err := executeKVList(t, server, "--output", "text")
	require.NoError(t, err)
	assert.NotContains(t, result.Stdout, "red-")
}

func TestKVList_MultipleInstances(t *testing.T) {
	server := renderapi.NewServer(t)
	kv1 := seedKV(server, "cache-one")
	kv2 := seedKV(server, "cache-two")

	result, err := executeKVList(t, server, "--output", "text")
	require.NoError(t, err)

	assert.Contains(t, result.Stdout, kv1.Id)
	assert.Contains(t, result.Stdout, "cache-one")
	assert.Contains(t, result.Stdout, kv2.Id)
	assert.Contains(t, result.Stdout, "cache-two")
}

func TestKVList_FilterByEnvironmentID(t *testing.T) {
	server := renderapi.NewServer(t)
	proj := server.CreateProject(
		renderapi.ProjectAttrs{Name: "My Project", OwnerId: kvTestWorkspaceID},
		renderapi.EnvAttrs{Name: "production"},
		renderapi.EnvAttrs{Name: "staging"},
	)

	prodKV := seedKVInEnv(server, "prod-cache", proj.Env("production").Id)
	stagingKV := seedKVInEnv(server, "staging-cache", proj.Env("staging").Id)

	result, err := executeKVList(t, server, "--environment", proj.Env("production").Id, "--output", "text")
	require.NoError(t, err)

	assert.Contains(t, result.Stdout, prodKV.Id)
	assert.NotContains(t, result.Stdout, stagingKV.Id)
}

func TestKVList_FilterByEnvironmentName(t *testing.T) {
	server := renderapi.NewServer(t)
	proj := server.CreateProject(
		renderapi.ProjectAttrs{Name: "My Project", OwnerId: kvTestWorkspaceID},
		renderapi.EnvAttrs{Name: "production"},
		renderapi.EnvAttrs{Name: "staging"},
	)

	prodKV := seedKVInEnv(server, "prod-cache", proj.Env("production").Id)
	stagingKV := seedKVInEnv(server, "staging-cache", proj.Env("staging").Id)

	result, err := executeKVList(t, server, "--environment", "production", "--output", "text")
	require.NoError(t, err)

	assert.Contains(t, result.Stdout, prodKV.Id)
	assert.NotContains(t, result.Stdout, stagingKV.Id)
}

func TestKVList_JSONOutput(t *testing.T) {
	server := renderapi.NewServer(t)
	proj := server.CreateProject(
		renderapi.ProjectAttrs{Name: "My Project", OwnerId: kvTestWorkspaceID},
		renderapi.EnvAttrs{Name: "production"},
	)
	first := seedKVInEnv(server, "json-cache-one", proj.Env("production").Id)
	second := seedKVInEnv(server, "json-cache-two", proj.Env("production").Id)

	result, err := executeKVList(t, server, "--output", "json")
	require.NoError(t, err)

	var body map[string]any
	require.NoError(t, json.Unmarshal([]byte(result.Stdout), &body))
	data := requireSubSlice(t, body, "data")
	require.Len(t, data, 2)
	require.IsType(t, map[string]any{}, data[0])
	require.IsType(t, map[string]any{}, data[1])
	firstItem := data[0].(map[string]any)
	secondItem := data[1].(map[string]any)

	assert.Equal(t, first.Id, firstItem["id"])
	assert.Equal(t, "json-cache-one", firstItem["name"])
	assert.Equal(t, second.Id, secondItem["id"])
	assert.Equal(t, "json-cache-two", secondItem["name"])
	assert.NotContains(t, firstItem, "keyValue")
}

func TestKVList_DefaultOutput_TreatedAsText(t *testing.T) {
	// No --output flag; the default ("interactive") should produce human-readable
	// text rather than launching a TUI.
	server := renderapi.NewServer(t)
	kv := seedKV(server, "default-out")

	result, err := executeKVList(t, server)
	require.NoError(t, err)

	assert.Contains(t, result.Stdout, kv.Id)
	assert.Contains(t, result.Stdout, "default-out")
}

func TestKVList_UnknownEnvironment_Errors(t *testing.T) {
	server := renderapi.NewServer(t)
	seedKV(server, "any-cache")

	_, err := executeKVList(t, server, "--environment", "does-not-exist", "--output", "text")
	require.Error(t, err)
	assert.Contains(t, err.Error(), "does-not-exist")
}

func TestKVList_FilterByProject(t *testing.T) {
	server := renderapi.NewServer(t)

	projectA := server.CreateProject(
		renderapi.ProjectAttrs{Name: "Project A", OwnerId: kvTestWorkspaceID},
		renderapi.EnvAttrs{Name: "production"},
		renderapi.EnvAttrs{Name: "staging"},
	)
	projectB := server.CreateProject(
		renderapi.ProjectAttrs{Name: "Project B", OwnerId: kvTestWorkspaceID},
		renderapi.EnvAttrs{Name: "production"},
	)

	aProdKV := seedKVInEnv(server, "a-prod-cache", projectA.Env("production").Id)
	aStagingKV := seedKVInEnv(server, "a-staging-cache", projectA.Env("staging").Id)
	bProdKV := seedKVInEnv(server, "b-prod-cache", projectB.Env("production").Id)

	result, err := executeKVList(t, server, "--project", "Project A", "--output", "text")
	require.NoError(t, err)

	assert.Contains(t, result.Stdout, aProdKV.Id)
	assert.Contains(t, result.Stdout, aStagingKV.Id)
	assert.NotContains(t, result.Stdout, bProdKV.Id)
}

func TestKVList_FilterByProjectAndEnvironment_NarrowsToEnvWithinProject(t *testing.T) {
	server := renderapi.NewServer(t)

	projectA := server.CreateProject(
		renderapi.ProjectAttrs{Name: "Project A", OwnerId: kvTestWorkspaceID},
		renderapi.EnvAttrs{Name: "production"},
	)
	projectB := server.CreateProject(
		renderapi.ProjectAttrs{Name: "Project B", OwnerId: kvTestWorkspaceID},
		renderapi.EnvAttrs{Name: "production"},
	)

	aProdKV := seedKVInEnv(server, "a-prod-cache", projectA.Env("production").Id)
	bProdKV := seedKVInEnv(server, "b-prod-cache", projectB.Env("production").Id)

	result, err := executeKVList(t, server,
		"--project", "Project A",
		"--environment", "production",
		"--output", "text",
	)
	require.NoError(t, err)

	assert.Contains(t, result.Stdout, aProdKV.Id)
	assert.NotContains(t, result.Stdout, bProdKV.Id)
}

func TestKVList_UnknownProject_Errors(t *testing.T) {
	server := renderapi.NewServer(t)
	seedKV(server, "any-cache")

	_, err := executeKVList(t, server, "--project", "does-not-exist", "--output", "text")
	require.Error(t, err)
	assert.Contains(t, err.Error(), "does-not-exist")
}
