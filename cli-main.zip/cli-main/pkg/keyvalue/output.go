package keyvalue

import (
	"time"

	"github.com/render-oss/cli/pkg/client"
)

// KeyValueOut is the JSON/YAML contract for a Key Value instance.
type KeyValueOut struct {
	ID              string                           `json:"id"`
	Name            string                           `json:"name"`
	Plan            client.KeyValuePlan              `json:"plan"`
	Region          client.Region                    `json:"region"`
	Status          client.DatabaseStatus            `json:"status"`
	CreatedAt       time.Time                        `json:"createdAt"`
	UpdatedAt       time.Time                        `json:"updatedAt"`
	Version         string                           `json:"version,omitempty"`
	OwnerID         string                           `json:"ownerId"`
	OwnerType       client.OwnerType                 `json:"ownerType,omitempty"`
	WorkspaceName   string                           `json:"-"`
	ProjectID       *string                          `json:"projectId"`
	ProjectName     string                           `json:"-"`
	EnvironmentID   *string                          `json:"environmentId"`
	EnvironmentName string                           `json:"-"`
	ConnectionInfo  *client.KeyValueConnectionInfo   `json:"connectionInfo,omitempty"`
	IPAllowList     []client.CidrBlockAndDescription `json:"ipAllowList"`
	MaxmemoryPolicy *string                          `json:"maxmemoryPolicy,omitempty"`
}

type KeyValueGetOut struct {
	Data KeyValueOut `json:"data"`
}

type KeyValueCreateOut = KeyValueGetOut

type KeyValueListOut struct {
	Data []KeyValueOut `json:"data"`
}

type DeleteOut struct {
	Data KeyValueOut   `json:"data"`
	Meta DeleteOutMeta `json:"meta"`
}

type DeleteOutMeta struct {
	Deleted bool   `json:"deleted"`
	Message string `json:"message,omitempty"`
}

type KeyValueResumeOut = KeyValueGetOut

type SuspendOut struct {
	Data KeyValueOut    `json:"data"`
	Meta SuspendOutMeta `json:"meta"`
}

type SuspendOutMeta struct {
	Suspended bool   `json:"suspended"`
	Message   string `json:"message,omitempty"`
}

type KeyValueUpdateOut struct {
	Data KeyValueOut        `json:"data"`
	Diff KeyValueUpdateDiff `json:"diff"`
}

type KeyValueUpdateDiff struct {
	Name            *KeyValueFieldDiff[string]                           `json:"name,omitempty"`
	Plan            *KeyValueFieldDiff[client.KeyValuePlan]              `json:"plan,omitempty"`
	MaxmemoryPolicy *KeyValueFieldDiff[*string]                          `json:"maxmemoryPolicy,omitempty"`
	IPAllowList     *KeyValueFieldDiff[[]client.CidrBlockAndDescription] `json:"ipAllowList,omitempty"`
}

type KeyValueFieldDiff[T any] struct {
	Before T `json:"before"`
	After  T `json:"after"`
}

func NewKeyValueOut(resolved *ResolvedKeyValue) KeyValueOut {
	if resolved == nil || resolved.KeyValue == nil {
		return KeyValueOut{}
	}

	kv := resolved.KeyValue
	out := KeyValueOut{
		ID:            kv.Id,
		Name:          kv.Name,
		Plan:          kv.Plan,
		Region:        kv.Region,
		Status:        kv.Status,
		CreatedAt:     kv.CreatedAt,
		UpdatedAt:     kv.UpdatedAt,
		Version:       kv.Version,
		OwnerID:       kv.Owner.Id,
		OwnerType:     kv.Owner.Type,
		WorkspaceName: kv.Owner.Name,
		IPAllowList:   kv.IpAllowList,
	}
	if out.IPAllowList == nil {
		out.IPAllowList = []client.CidrBlockAndDescription{}
	}
	if kv.Options.MaxmemoryPolicy != nil {
		out.MaxmemoryPolicy = kv.Options.MaxmemoryPolicy
	}
	if kv.EnvironmentId != nil {
		out.EnvironmentID = kv.EnvironmentId
	}
	if resolved.Environment != nil {
		out.EnvironmentID = &resolved.Environment.Id
		out.EnvironmentName = resolved.Environment.Name
	}
	if resolved.Project != nil {
		out.ProjectID = &resolved.Project.Id
		out.ProjectName = resolved.Project.Name
	}
	return out
}

func NewKeyValueListOut(models []*Model) KeyValueListOut {
	data := make([]KeyValueOut, 0, len(models))
	for _, model := range models {
		data = append(data, NewKeyValueOutFromModel(model))
	}
	return KeyValueListOut{Data: data}
}

func NewKeyValueOutFromModel(model *Model) KeyValueOut {
	if model == nil || model.KeyValue == nil {
		return KeyValueOut{}
	}

	kv := model.KeyValue
	out := KeyValueOut{
		ID:            kv.Id,
		Name:          kv.Name,
		Plan:          kv.Plan,
		Region:        kv.Region,
		Status:        kv.Status,
		CreatedAt:     kv.CreatedAt,
		UpdatedAt:     kv.UpdatedAt,
		Version:       kv.Version,
		OwnerID:       kv.Owner.Id,
		OwnerType:     kv.Owner.Type,
		WorkspaceName: kv.Owner.Name,
		IPAllowList:   kv.IpAllowList,
	}
	if out.IPAllowList == nil {
		out.IPAllowList = []client.CidrBlockAndDescription{}
	}
	if kv.Options.MaxmemoryPolicy != nil {
		out.MaxmemoryPolicy = kv.Options.MaxmemoryPolicy
	}
	if kv.EnvironmentId != nil {
		out.EnvironmentID = kv.EnvironmentId
	}
	if model.Environment != nil {
		out.EnvironmentID = &model.Environment.Id
		out.EnvironmentName = model.Environment.Name
	}
	if model.Project != nil {
		out.ProjectID = &model.Project.Id
		out.ProjectName = model.Project.Name
	}
	return out
}
