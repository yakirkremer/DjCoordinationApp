package types_test

import (
	"testing"

	"github.com/render-oss/cli/pkg/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestParseIPAllowListEntry(t *testing.T) {
	t.Run("parses cidr with description", func(t *testing.T) {
		cidr, desc, err := types.ParseIPAllowListEntry("cidr=10.0.0.0/8,description=Internal")
		require.NoError(t, err)
		assert.Equal(t, "10.0.0.0/8", cidr)
		assert.Equal(t, "Internal", desc)
	})

	t.Run("parses cidr without description", func(t *testing.T) {
		cidr, desc, err := types.ParseIPAllowListEntry("cidr=10.0.0.0/8")
		require.NoError(t, err)
		assert.Equal(t, "10.0.0.0/8", cidr)
		assert.Equal(t, "", desc)
	})

	t.Run("handles IPv6 CIDR", func(t *testing.T) {
		cidr, desc, err := types.ParseIPAllowListEntry("cidr=2001:db8::/32,description=IPv6 range")
		require.NoError(t, err)
		assert.Equal(t, "2001:db8::/32", cidr)
		assert.Equal(t, "IPv6 range", desc)
	})

	t.Run("rejects malformed input missing cidr key", func(t *testing.T) {
		_, _, err := types.ParseIPAllowListEntry("malformed")
		require.Error(t, err)
		assert.Contains(t, err.Error(), "must start with cidr=")
	})

	t.Run("rejects empty cidr value", func(t *testing.T) {
		_, _, err := types.ParseIPAllowListEntry("cidr=")
		require.Error(t, err)
		assert.Contains(t, err.Error(), "cidr value is empty")
	})

	t.Run("rejects empty cidr value with description", func(t *testing.T) {
		_, _, err := types.ParseIPAllowListEntry("cidr=,description=foo")
		require.Error(t, err)
		assert.Contains(t, err.Error(), "cidr value is empty")
	})

	t.Run("rejects invalid CIDR", func(t *testing.T) {
		_, _, err := types.ParseIPAllowListEntry("cidr=not-a-cidr")
		require.Error(t, err)
		assert.Contains(t, err.Error(), "invalid CIDR")
	})

	t.Run("rejects IP without prefix length", func(t *testing.T) {
		_, _, err := types.ParseIPAllowListEntry("cidr=10.0.0.1")
		require.Error(t, err)
		assert.Contains(t, err.Error(), "invalid CIDR")
	})
}

func TestParseIPAllowList(t *testing.T) {
	t.Run("parses each entry into a CidrBlockAndDescription", func(t *testing.T) {
		out, err := types.ParseIPAllowList([]string{
			"cidr=10.0.0.0/8,description=Internal",
			"cidr=203.0.113.5/32",
		})
		require.NoError(t, err)
		require.Len(t, out, 2)
		assert.Equal(t, "10.0.0.0/8", out[0].CidrBlock)
		assert.Equal(t, "Internal", out[0].Description)
		assert.Equal(t, "203.0.113.5/32", out[1].CidrBlock)
		assert.Equal(t, "", out[1].Description)
	})

	t.Run("propagates entry-level errors", func(t *testing.T) {
		_, err := types.ParseIPAllowList([]string{"malformed"})
		require.Error(t, err)
		assert.Contains(t, err.Error(), "must start with cidr=")
	})

	t.Run("nil input yields empty slice", func(t *testing.T) {
		out, err := types.ParseIPAllowList(nil)
		require.NoError(t, err)
		assert.Empty(t, out)
	})
}

func TestFormatIPAllowListEntry(t *testing.T) {
	t.Run("formats cidr with description", func(t *testing.T) {
		result := types.FormatIPAllowListEntry("10.0.0.0/8", "Internal")
		assert.Equal(t, "cidr=10.0.0.0/8,description=Internal", result)
	})

	t.Run("formats cidr without description", func(t *testing.T) {
		result := types.FormatIPAllowListEntry("10.0.0.0/8", "")
		assert.Equal(t, "cidr=10.0.0.0/8", result)
	})

	t.Run("formats IPv6 cidr with description", func(t *testing.T) {
		result := types.FormatIPAllowListEntry("2001:db8::/32", "IPv6 range")
		assert.Equal(t, "cidr=2001:db8::/32,description=IPv6 range", result)
	})

	t.Run("formats IPv6 cidr without description", func(t *testing.T) {
		result := types.FormatIPAllowListEntry("2001:db8::/32", "")
		assert.Equal(t, "cidr=2001:db8::/32", result)
	})
}
