package service

import (
	"context"
	"fmt"
	"net/http"
	"strings"

	"github.com/render-oss/cli/pkg/client"
	"github.com/render-oss/cli/pkg/config"
	"github.com/render-oss/cli/pkg/pointers"
	rstrings "github.com/render-oss/cli/pkg/strings"
	"github.com/render-oss/cli/pkg/tui"
	"github.com/render-oss/cli/pkg/validate"
)

type Repo struct {
	client *client.ClientWithResponses
}

func NewRepo(c *client.ClientWithResponses) *Repo {
	return &Repo{
		client: c,
	}
}

func (s *Repo) ListServices(ctx context.Context, params *client.ListServicesParams) ([]*client.Service, error) {
	workspace, err := config.WorkspaceID()
	if err != nil {
		return nil, err
	}
	if workspace != "" {
		params.OwnerId = pointers.From([]string{workspace})
	}

	return client.ListAll(ctx, params, s.listPage)
}

func (s *Repo) listPage(ctx context.Context, params *client.ListServicesParams) ([]*client.Service, *client.Cursor, error) {
	resp, err := s.client.ListServicesWithResponse(ctx, params)
	if err != nil {
		return nil, nil, err
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return nil, nil, err
	}
	if resp.JSON200 == nil || len(*resp.JSON200) == 0 {
		return nil, nil, nil
	}

	res := *resp.JSON200
	services := make([]*client.Service, 0, len(res))
	for _, serviceWithCursor := range res {
		services = append(services, &serviceWithCursor.Service)
	}

	return services, &res[len(res)-1].Cursor, nil
}

func (s *Repo) DeployService(ctx context.Context, svc *client.Service) (*client.Deploy, error) {
	if err := validate.WorkspaceMatches(svc.OwnerId); err != nil {
		return nil, err
	}

	resp, err := s.client.CreateDeployWithResponse(ctx, svc.Id, client.CreateDeployJSONRequestBody{
		ClearCache: nil,
		CommitId:   nil,
		ImageUrl:   nil,
	})
	if err != nil {
		return nil, err
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return nil, err
	}

	return resp.JSON201, nil
}

func (s *Repo) CreateService(ctx context.Context, data client.CreateServiceJSONRequestBody) (*client.Service, error) {
	if err := validate.WorkspaceMatches(data.OwnerId); err != nil {
		return nil, err
	}

	resp, err := s.client.CreateServiceWithResponse(ctx, data)
	if err != nil {
		return nil, err
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return nil, err
	}

	return resp.JSON201.Service, nil
}

// UpdateService PATCHes the given service. It does not re-fetch the service to
// validate workspace ownership, so the caller must pass an id already resolved
// against the active workspace (GetService and ResolveServiceIDFromNameOrID
// both validate ownership and return such an id).
func (s *Repo) UpdateService(ctx context.Context, id string, data client.UpdateServiceJSONRequestBody) (*client.Service, error) {
	resp, err := s.client.UpdateServiceWithResponse(ctx, id, data)
	if err != nil {
		return nil, err
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return nil, err
	}

	return resp.JSON200, nil
}

func (s *Repo) DeleteService(ctx context.Context, id string) error {
	// GetService validates that the service belongs to the active workspace.
	if _, err := s.GetService(ctx, id); err != nil {
		return err
	}

	resp, err := s.client.DeleteServiceWithResponse(ctx, id)
	if err != nil {
		return err
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return err
	}

	return nil
}

func (s *Repo) GetService(ctx context.Context, id string) (*client.Service, error) {
	resp, err := s.client.RetrieveServiceWithResponse(ctx, id)
	if err != nil {
		return nil, err
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return nil, err
	}

	if err := validate.WorkspaceMatches(resp.JSON200.OwnerId); err != nil {
		return nil, err
	}

	return resp.JSON200, nil
}

func (s *Repo) RestartService(ctx context.Context, id string) error {
	resp, err := s.client.RestartServiceWithResponse(ctx, id)
	if err != nil {
		return err
	}

	if err := client.ErrorFromResponse(resp); err != nil {
		return err
	}

	return nil
}

func (s *Repo) ResolveServiceIDFromNameOrID(ctx context.Context, idOrName string) (string, error) {
	return s.resolveServiceIDFromNameOrID(ctx, idOrName, looksLikeServiceID)
}

func (s *Repo) resolveServiceIDFromNameOrID(ctx context.Context, idOrName string, looksLikeID func(string) bool) (string, error) {
	query := strings.TrimSpace(idOrName)
	if query == "" {
		return "", fmt.Errorf("service ID or name is required")
	}

	if looksLikeID(query) {
		resp, err := s.client.RetrieveServiceWithResponse(ctx, query)
		if err != nil {
			return "", err
		}

		// On 404, fall through to name search. This handles edge cases where
		// a service name looks like an ID but isn't one.
		if resp.StatusCode() != http.StatusNotFound {
			if err := client.ErrorFromResponse(resp); err != nil {
				return "", err
			}
			if resp.JSON200 == nil {
				return "", fmt.Errorf("service lookup failed for %q: empty response", query)
			}
			if err := validate.WorkspaceMatches(resp.JSON200.OwnerId); err != nil {
				return "", err
			}
			return resp.JSON200.Id, nil
		}
	}

	services, err := s.ListServices(ctx, &client.ListServicesParams{
		Name: &client.NameParam{query},
	})
	if err != nil {
		return "", err
	}

	exactMatches := make([]*client.Service, 0, len(services))
	for _, svc := range services {
		if svc != nil && svc.Name == query {
			exactMatches = append(exactMatches, svc)
		}
	}

	switch len(exactMatches) {
	case 0:
		return "", serviceNotFoundError(query)
	case 1:
		return exactMatches[0].Id, nil
	default:
		return "", tui.UserFacingError{Message: multipleServicesMessage(query)}
	}
}

func looksLikeServiceID(v string) bool {
	return validate.IsServiceID(v) || validate.IsCronJobID(v)
}

func serviceNotFoundError(idOrName string) tui.UserFacingError {
	if looksLikeServiceID(idOrName) {
		return tui.UserFacingError{Message: fmt.Sprintf("No service with ID '%s'.", idOrName)}
	}
	workspace := activeWorkspaceLabel()
	if workspace == "" {
		return tui.UserFacingError{Message: fmt.Sprintf("No service named '%s'.", idOrName)}
	}
	return tui.UserFacingError{Message: fmt.Sprintf(
		"No service named '%s' in workspace %s. To search another workspace, run `render workspace set <name|ID>`, or pass the service ID instead.",
		idOrName, workspace,
	)}
}

func multipleServicesMessage(name string) string {
	return fmt.Sprintf("Multiple services found with name '%s'. Pass the service ID to disambiguate.", name)
}

func activeWorkspaceLabel() string {
	id, _ := config.WorkspaceID()
	name, _ := config.WorkspaceName()
	return rstrings.ResourceLabel(name, id)
}
